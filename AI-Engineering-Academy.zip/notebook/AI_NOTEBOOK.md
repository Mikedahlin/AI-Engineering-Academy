# AI Notebook

This is my personal AI encyclopedia.
Every important concept should be explained simply enough that I can come back later and understand it fast.

---

## Concept Template

### Concept Name

### What It Is
Explain the concept in simple language.

### Why It Exists
What problem does it solve?

### Why It Matters for AI
How does it show up in real AI systems?

### Real-World Example
Give one practical example.

### Explain It to Mom
Explain it in plain English with no programmer talk.

### Common Confusions
- 

### How I Might Use It
- 

---

## Starter Concepts to Add Over Time
- API
- JSON
- Python
- Token
- Context window
- Embedding
- Vector database
- Transformer
- Inference
- Hallucination
- RAG
- Agent
- Tool calling
- Fine-tuning
- GPU
