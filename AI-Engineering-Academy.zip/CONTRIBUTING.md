# Contributing

Help improve the Academy while keeping its core philosophy:

1. One concept per lesson.
2. Explain in plain English.
3. Connect every topic to real AI.
4. End each lesson with an 'Explain It to Mom' checkpoint.
5. Keep ADHD-friendly pacing.
