# Parking Lot

This file protects focus.
If something is interesting but not part of today's mission, it goes here instead of hijacking the lesson.

---

## How to Use This
- Write the idea down
- Do not chase it during the current lesson
- Revisit it later when it actually fits the roadmap

---

## Parking Lot Entry Template

### Topic

### Why I Want to Explore It

### When to Revisit It
- Soon
- Later
- Only if it becomes relevant

### Notes
- 

---

## Possible Future Topics
- Quantum computing and AI
- Robotics
- AGI
- Synthetic intelligence design
- Custom model training
- Voice agents
- Multi-agent business systems
