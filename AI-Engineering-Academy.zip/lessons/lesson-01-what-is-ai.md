# Lesson 1 - What Is AI?

Mission:
Understand that AI is software trained to recognize patterns in data and use those patterns to make predictions or generate responses.

Explain It to Mom:
'AI is a computer program that learned patterns from lots of information so it can make really good guesses.'
