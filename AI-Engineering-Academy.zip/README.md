# AI Engineering Academy

> Created by **Michael "Big Mike" Dahlin**

An open-source AI engineering curriculum designed around ADHD-friendly learning principles.

## Philosophy

- One concept at a time
- No rabbit holes
- Understand before memorizing
- Every lesson connects to real AI
- Built to reduce overwhelm while remaining technically accurate

Although inspired by the way many people with ADHD/ADD learn, this curriculum is for anyone who wants a clearer path into AI engineering.

## Repository Structure

- lessons/ – Step-by-step curriculum
- notebook/ – AI encyclopedia
- progress/ – Lesson logs and victories
- projects/ – Hands-on builds
- examples/ – Sample code
- resources/ – References

## Contributing

Pull requests are welcome. Please preserve the teaching philosophy of short, focused lessons.
