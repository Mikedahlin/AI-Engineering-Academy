# AI Engineering Academy Roadmap

## Mission
Turn AI from "magic that helps me" into systems I can understand, direct, debug, improve, and eventually build.

## Core Rule
We are not learning tech just because school teaches it.
We learn it if it helps me understand, build, fix, or deploy AI systems.

## How We Work
- One lesson at a time
- One clear mission per session
- No rabbit holes during the main lesson
- Every topic must connect back to AI
- Understanding matters more than memorization
- Every lesson ends with an "Explain it to Mom" check

## Phase 1: Foundations That Stop the Computer From Feeling Mysterious
- [ ] Files and folders
- [ ] What apps, files, and projects actually are
- [ ] Terminal basics
- [ ] VS Code basics
- [ ] Git basics
- [ ] GitHub basics
- [ ] JSON basics
- [ ] APIs basics
- [ ] Python basics for AI work

## Phase 2: How Modern AI Works
- [ ] What AI, machine learning, and deep learning mean
- [ ] What an LLM is
- [ ] Tokens
- [ ] Context windows
- [ ] Embeddings
- [ ] Vector search
- [ ] Transformers
- [ ] Attention
- [ ] Inference
- [ ] Why hallucinations happen

## Phase 3: Building Useful AI Systems
- [ ] Calling an AI API
- [ ] Prompt design
- [ ] Structured outputs
- [ ] Tool calling
- [ ] RAG
- [ ] Memory
- [ ] Agents
- [ ] Multi-step workflows
- [ ] Evaluation basics

## Phase 4: Production AI
- [ ] Local models
- [ ] GPUs and inference speed
- [ ] Model selection
- [ ] Cost and latency tradeoffs
- [ ] Logging and debugging
- [ ] Security basics
- [ ] Deployment basics
- [ ] Monitoring and maintenance

## Phase 5: Build My Own AI Products
- [ ] Build KIRA-related AI workflows
- [ ] Build at least one complete AI app
- [ ] Fix bugs in AI-generated code with understanding
- [ ] Design AI systems around real business problems
- [ ] Document repeatable workflows

## Current Focus
- [ ] Set up the Academy system
- [ ] Start Lesson 1

## Parking Lot Reminder
If a topic is interesting but not needed for today's mission, put it in `PARKING_LOT.md`.
